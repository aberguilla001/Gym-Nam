package com.example.asier.gymam;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.content.Intent;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class Fragment1 extends Fragment {

    Activity context;

    public Fragment1() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        context = getActivity();
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fragment1, container, false);
    }

    public void onStart(){

        super.onStart();
        /// selecciona la lista en pantalla segun su ID
        ListView lista1 = (ListView) context.findViewById(R.id.listView);

        // registra una accion para el evento click
        lista1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                /// Obtiene el valor de la casilla elegida
                String itemSeleccionado = adapterView.getItemAtPosition(i).toString();

                if (itemSeleccionado.equals("Mi rutina"))
                {
                    Intent intent = new Intent(context, MiRutina.class);
                    startActivity(intent);
                }
                else if (itemSeleccionado.equals("Crear rutina automática"))
                {
                    Intent intent = new Intent(context, CrearRutinaAuto.class);
                    startActivity(intent);
                }
                else if (itemSeleccionado.equals("Crear rutina manual"))
                {
                    Intent intent = new Intent(context, RutinaMan.class);
                    startActivity(intent);
                }
                else if (itemSeleccionado.equals("Tutoriales"))
                {
                    Intent intent = new Intent(context, Tutoriales.class);
                    startActivity(intent);
                }

            }
        });

    }
}
package com.example.asier.gymam;

//import android.app.Fragment;
import android.app.Activity;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.SimpleCursorAdapter;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.support.v4.app.Fragment;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

/**
 * Created by asier on 7/03/16.
 */
public class FragmentDia1 extends Fragment {

    private EjerciciosDbAdapter dbAdapter;
    private Cursor cursor;

    //
    // Identificador del registro que se edita cuando la opción es MODIFICAR
    //
    private long id ;

    //
    // Elementos de la vista
    //
    private Spinner situacion ;
    private Spinner situacion2 ;
    private Spinner situacion3;
    private Spinner situacion4;
    private Spinner situacion5;
    private Spinner situacion6;
    private Spinner situacion7;

    Activity context;

    public static FragmentDia1 newInstance() {
        FragmentDia1 fragment = new FragmentDia1();
        return fragment;
    }

    public FragmentDia1(){
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        context = getActivity();
        View rootView = inflater.inflate(R.layout.fragment_fragmentdia1, container, false);
        return rootView;
    }


   @Override
   public void onActivityCreated(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        situacion = (Spinner) context.findViewById(R.id.situacion);
        situacion2 = (Spinner) context.findViewById(R.id.situacion2);
        situacion3 = (Spinner) context.findViewById(R.id.situacion3);
        situacion4 = (Spinner) context.findViewById(R.id.situacion4);
        situacion5 = (Spinner) context.findViewById(R.id.situacion5);
        situacion6 = (Spinner) context.findViewById(R.id.situacion6);
        situacion7 = (Spinner) context.findViewById(R.id.situacion7);

        dbAdapter = new EjerciciosDbAdapter(getActivity());
        dbAdapter.abrir();

        cursor = dbAdapter.getCursor();

       SimpleCursorAdapter adapterSituacion = new SimpleCursorAdapter(context,android.R.layout.simple_spinner_item,cursor,new String[] {EjerciciosDbAdapter.C_COLUMNA_NOMBRE}, new int[] {android.R.id.text1});

       adapterSituacion.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

       situacion.setAdapter(adapterSituacion);
       situacion2.setAdapter(adapterSituacion);
       situacion3.setAdapter(adapterSituacion);
       situacion4.setAdapter(adapterSituacion);
       situacion5.setAdapter(adapterSituacion);
       situacion6.setAdapter(adapterSituacion);
       situacion7.setAdapter(adapterSituacion);

       Button boton_guardar = (Button) context.findViewById(R.id.savebutton);
       boton_guardar.setOnClickListener(new View.OnClickListener() {

           @Override
           public void onClick(View v) {
               guardar();
           }
       });
   }

    private void guardar()
    {
        //
        // Obtenemos los datos del formulario
        //
        ContentValues reg = new ContentValues();
        ContentValues reg2 = new ContentValues();
        ContentValues reg3 = new ContentValues();
        ContentValues reg4 = new ContentValues();
        ContentValues reg5 = new ContentValues();
        ContentValues reg6 = new ContentValues();
        ContentValues reg7 = new ContentValues();

        reg.put(EjerciciosDbAdapter.C_COLUMNA_DIA1, situacion.getSelectedItemId());
        reg2.put(EjerciciosDbAdapter.C_COLUMNA_DIA1, situacion2.getSelectedItemId());
        reg3.put(EjerciciosDbAdapter.C_COLUMNA_DIA1, situacion3.getSelectedItemId());
        reg4.put(EjerciciosDbAdapter.C_COLUMNA_DIA1, situacion4.getSelectedItemId());
        reg5.put(EjerciciosDbAdapter.C_COLUMNA_DIA1, situacion5.getSelectedItemId());
        reg6.put(EjerciciosDbAdapter.C_COLUMNA_DIA1, situacion6.getSelectedItemId());
        reg7.put(EjerciciosDbAdapter.C_COLUMNA_DIA1, situacion7.getSelectedItemId());

        dbAdapter.insert(reg);
        dbAdapter.insert(reg2);
        dbAdapter.insert(reg3);
        dbAdapter.insert(reg4);
        dbAdapter.insert(reg5);
        dbAdapter.insert(reg6);
        dbAdapter.insert(reg7);

        Toast.makeText(context,"Añadido", Toast.LENGTH_SHORT).show();

    }

    private void consultar(long id)
    {
        //
        // Consultamos el centro por el identificador
        //
        cursor = dbAdapter.getRegistro(id);

        situacion.setSelection(getItemPositionById(cursor, cursor.getLong(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_NOMBRE))));
        situacion2.setSelection(getItemPositionById(cursor, cursor.getLong(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_NOMBRE))));
        situacion3.setSelection(getItemPositionById(cursor, cursor.getLong(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_NOMBRE))));
        situacion4.setSelection(getItemPositionById(cursor, cursor.getLong(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_NOMBRE))));
        situacion5.setSelection(getItemPositionById(cursor, cursor.getLong(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_NOMBRE))));
        situacion6.setSelection(getItemPositionById(cursor, cursor.getLong(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_NOMBRE))));
        situacion7.setSelection(getItemPositionById(cursor, cursor.getLong(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_NOMBRE))));

    }

    private int getItemPositionById(Cursor c, long id)
    {
        for(c.moveToFirst(); !c.isAfterLast(); c.moveToNext())
        {
            if (c.getLong(c.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_ID)) == id)
            {
                return c.getPosition() ;
            }
        }

        return 0 ;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        context.getMenuInflater().inflate(R.menu.menu_rutina_man, menu);
        return true;
    }
}

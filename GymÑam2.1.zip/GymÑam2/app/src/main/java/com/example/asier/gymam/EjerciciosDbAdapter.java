package com.example.asier.gymam;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by asier on 8/03/16.
 */
public class EjerciciosDbAdapter {
    /**
     * Definimos constante con el nombre de la tabla
     */
    public static final String C_TABLA  = "EJERCICIOS";
    public static final String C_TABLA2 = "RUTINA";
    /**
     * Definimos constantes con el nombre de las columnas de la tabla
     */
    public static final String C_COLUMNA_ID   = "_id";
    public static final String C_COLUMNA_NOMBRE = "ej_nombre";
    public static final String C_COLUMNA_GRUPO = "ej_grupo";

    public static final String C_COLUMNA_DIA1 ="dia1";
    public static final String C_COLUMNA_DIA2 ="dia2";
    public static final String C_COLUMNA_DIA3 ="dia3";
    public static final String C_COLUMNA_DIA4 ="dia4";
    public static final String C_COLUMNA_DIA5 ="dia5";

    private Context contexto;
    private EjerciciosDbHelper dbHelper;
    private SQLiteDatabase db;
    /**
     * Definimos lista de columnas de la tabla para utilizarla en las consultas a la base de datos
     */
    private String[] columnas = new String[]{ C_COLUMNA_ID, C_COLUMNA_NOMBRE, C_COLUMNA_GRUPO} ;
    private String[] columnas2 = new String[]{C_COLUMNA_ID, C_COLUMNA_DIA1, C_COLUMNA_DIA2, C_COLUMNA_DIA3, C_COLUMNA_DIA4, C_COLUMNA_DIA5} ;

    public EjerciciosDbAdapter(Context context)
    {
        this.contexto=context;
    }

    public EjerciciosDbAdapter abrir() throws SQLException
    {
        dbHelper = new EjerciciosDbHelper(contexto);
        db = dbHelper.getWritableDatabase();
        return this;
    }

    public void cerrar()
    {
        dbHelper.close();
    }

    /**
     * Devuelve cursor con todos las columnas de la tabla
     */
    public Cursor getCursor() throws SQLException
    {
        Cursor c = db.query( true, C_TABLA, columnas, null, null, null, null, null, null);

        return c;
    }

    public Cursor getCursor2() throws SQLException
    {
        Cursor c = db.query( true, C_TABLA2, columnas2, null, null, null, null, null, null);

        return c;
    }

    public Cursor getRegistro(long id) throws SQLException
    {
        Cursor c = db.query( true, C_TABLA, columnas, C_COLUMNA_ID + "=" + id, null, null, null, null, null);

        //Nos movemos al primer registro de la consulta
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    /**
     * Inserta los valores en un registro de la tabla
     */
    public long insert(ContentValues reg)
    {
        if (db == null)
            abrir();

        return db.insert(C_TABLA2, null, reg);
    }
}

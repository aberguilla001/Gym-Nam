package com.example.asier.gymam;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.support.v4.app.Fragment;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;

/**
 * Created by asier on 7/03/16.
 */
public class FragmentDia2 extends Fragment {

    private EjerciciosDbAdapter dbAdapter;
    private Cursor cursor;
    private EjerciciosCursorAdapter hipotecaAdapter ;
    private ListView lista;
    Activity context;

    public static FragmentDia2 newInstance() {
        FragmentDia2 fragment = new FragmentDia2();
        return fragment;
    }

    public FragmentDia2(){
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        context = getActivity();
        View rootView = inflater.inflate(R.layout.fragment_fragmentdia2, container, false);
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //context.setContentView(R.layout.fragment_fragmentdia1);

        lista = (ListView) context.findViewById(R.id.list2);
        lista.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);

        dbAdapter = new EjerciciosDbAdapter(getActivity());
        dbAdapter.abrir();

        consultar();
    }

    private void consultar()
    {
        cursor = dbAdapter.getCursor();
        getActivity().startManagingCursor(cursor);
        hipotecaAdapter = new EjerciciosCursorAdapter(getActivity(), cursor);
        lista.setAdapter(hipotecaAdapter);
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        context.getMenuInflater().inflate(R.menu.menu_rutina_man, menu);
        return true;
    }

    /*public void deleteSelected(View view) {
        //Obtengo los elementos seleccionados de mi lista
        SparseBooleanArray seleccionados = lista.getCheckedItemPositions();

        if(seleccionados==null || seleccionados.size()==0){
            //Si no había elementos seleccionados...
            Toast.makeText(context, "No hay elementos seleccionados", Toast.LENGTH_SHORT).show();
        }else{
            //si los había, miro sus valores

            //Esto es para ir creando un mensaje largo que mostraré al final
            StringBuilder resultado=new StringBuilder();
            resultado.append("Se eliminarán los siguientes elementos:\n");

            //Recorro my "array" de elementos seleccionados
            final int size=seleccionados.size();
            for (int i=0; i<size; i++) {
                //Si valueAt(i) es true, es que estaba seleccionado
                if (seleccionados.valueAt(i)) {
                    //en keyAt(i) obtengo su posición
                    resultado.append("El elemento "+seleccionados.keyAt(i)+" estaba seleccionado\n");
                }
            }
            Toast.makeText(context, resultado.toString(), Toast.LENGTH_LONG).show();
        }
    }*/
}
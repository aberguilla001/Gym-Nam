package com.example.asier.gymam;

/**
 * Created by asier on 3/03/16.
 */
public class User {
    public long userId;
    public String username;
    public String password;
    public String nombre;
    public String apellidos;
    public String edad;
    public String altura;
    public String peso;



    public String sexo;
    public String objetivo;

    public User(long userId, String username, String password){
        this.userId=userId;
        this.username=username;
        this.password=password;
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.edad=edad;
        this.altura=altura;
        this.peso=peso;
        this.sexo=sexo;
        this.objetivo=objetivo;
    }

    /*public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }*/
}

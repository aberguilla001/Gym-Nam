package com.example.asier.gymam;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


public class Fragment3 extends Fragment {

    Activity context;
    private User myUser;



    public Fragment3() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        context = getActivity();
        return inflater.inflate(R.layout.fragment_fragment3, container, false);
    }


    @Override
    public void onStart() {

        super.onStart();

        Button bt = (Button) context.findViewById(R.id.buttonf3);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText mEmail = (EditText) context.findViewById(R.id.editText3);
                String email = mEmail.getText().toString();
                EditText mnombre = (EditText) context.findViewById(R.id.editText);
                String nombre = mnombre.getText().toString();
                EditText mapellidos = (EditText) context.findViewById(R.id.editText2);
                String apellidos = mapellidos.getText().toString();
                EditText medad = (EditText) context.findViewById(R.id.editText5);
                String edad = medad.getText().toString();
                EditText maltura = (EditText) context.findViewById(R.id.editText6);
                String altura = maltura.getText().toString();
                EditText mpeso = (EditText) context.findViewById(R.id.editText7);
                String peso = mpeso.getText().toString();
                EditText msexo = (EditText) context.findViewById(R.id.editText8);
                String sexo = msexo.getText().toString();
                EditText mobjetivo = (EditText) context.findViewById(R.id.editText9);
                String objetivo = mobjetivo.getText().toString();

                DBTools bd = null;
                try {
                    bd = new DBTools(context);
                    myUser = new User(1,email,"");
                    myUser.nombre = nombre;
                    myUser.apellidos = apellidos;
                    myUser.edad = edad;
                    myUser.altura = altura;
                    myUser.peso = peso;
                    myUser.sexo = sexo;
                    myUser.objetivo = objetivo;
                    myUser = bd.insertarDatos(myUser);
                    Toast myToast = Toast.makeText(context, "Datos añadidos", Toast.LENGTH_SHORT);
                    myToast.show();
                } finally {
                    if (bd != null)
                        bd.close();
                }

            }
        });



    }
}
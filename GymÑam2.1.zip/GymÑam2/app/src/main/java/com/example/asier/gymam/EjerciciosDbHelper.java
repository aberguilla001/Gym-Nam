package com.example.asier.gymam;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by asier on 8/03/16.
 */
public class EjerciciosDbHelper extends SQLiteOpenHelper {

    private static int version = 1;
    private static String name = "EjerciciosDb" ;
    private static SQLiteDatabase.CursorFactory factory = null;

    public EjerciciosDbHelper(Context context)
    {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL( "CREATE TABLE EJERCICIOS(" +
                " _id INTEGER PRIMARY KEY," +
                " ej_nombre TEXT NOT NULL, " +
                " ej_grupo TEXT)" );

        db.execSQL( "CREATE TABLE RUTINA(" +
                " _id INTEGER PRIMARY KEY," +
                        " dia1 TEXT," +
                        " dia2 TEXT," +
                        " dia3 TEXT," +
                        " dia4 TEXT," +
                        " dia5 TEXT)" );

        db.execSQL("CREATE UNIQUE INDEX ej_nombre ON EJERCICIOS(ej_nombre ASC)");

   /*
    * Insertamos datos iniciales
    */
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(1,'Press banca','Pecho')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(2,'Aperturas mancuernas','Pecho')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(3,'Dominadas','Espalda')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(4,'Remo polea baja','Espalda')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(5,'Press militar','Hombro')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(6,'Elevaciones laterales','Hombro')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(7,'Curl barra','Biceps')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(8,'Press francés','Triceps')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(9,'Sentadillas','Pierna')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(10,'Prensa inclinada','Pierna')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(11,'Extensiones','Pierna')");
        db.execSQL("INSERT INTO EJERCICIOS(_id, ej_nombre,ej_grupo) VALUES(12,'Femoral','Pierna')");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {

    }


}

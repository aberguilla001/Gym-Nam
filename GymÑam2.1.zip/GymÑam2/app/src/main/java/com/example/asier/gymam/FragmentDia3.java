package com.example.asier.gymam;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;

/**
 * Created by asier on 7/03/16.
 */
public class FragmentDia3 extends Fragment {

    private EjerciciosDbAdapter dbAdapter;
    private Cursor cursor;
    private EjerciciosCursorAdapter hipotecaAdapter ;
    private ListView lista;
    Activity context;

    public static FragmentDia3 newInstance() {
        FragmentDia3 fragment = new FragmentDia3();
        return fragment;
    }

    public FragmentDia3(){
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        context = getActivity();
        View rootView = inflater.inflate(R.layout.fragment_fragmentdia3, container, false);
        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //context.setContentView(R.layout.fragment_fragmentdia1);

        lista = (ListView) context.findViewById(R.id.list3);
        lista.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);

        dbAdapter = new EjerciciosDbAdapter(getActivity());
        dbAdapter.abrir();

        consultar();
    }

    private void consultar()
    {
        cursor = dbAdapter.getCursor();
        getActivity().startManagingCursor(cursor);
        hipotecaAdapter = new EjerciciosCursorAdapter(getActivity(), cursor);
        lista.setAdapter(hipotecaAdapter);
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        context.getMenuInflater().inflate(R.menu.menu_rutina_man, menu);
        return true;
    }
}
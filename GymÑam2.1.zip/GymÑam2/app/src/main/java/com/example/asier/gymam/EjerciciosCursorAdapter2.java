package com.example.asier.gymam;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

/**
 * Created by asier on 8/03/16.
 */
public class EjerciciosCursorAdapter2 extends CursorAdapter {

    private EjerciciosDbAdapter dbAdapter = null ;

    public EjerciciosCursorAdapter2(Context context, Cursor c)
    {
        super(context, c);
        dbAdapter = new EjerciciosDbAdapter(context);
        dbAdapter.abrir();
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor)
    {
        TextView tv = (TextView) view ;

        if (cursor.getString(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_DIA1)).equals("1"))
        {
            tv.setText("Press banca");
        }
        else if (cursor.getString(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_DIA1)).equals("2"))
        {
            tv.setText("Aperturas mancuernas");
        }
        else if (cursor.getString(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_DIA1)).equals("3"))
        {
            tv.setText("Dominadas");
        }
        else if (cursor.getString(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_DIA1)).equals("4"))
        {
            tv.setText("Remo polea baja");
        }
        else if (cursor.getString(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_DIA1)).equals("5"))
        {
            tv.setText("Press militar");
        }
        else if (cursor.getString(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_DIA1)).equals("6"))
        {
            tv.setText("Elevaciones laterales");
        }
        else if (cursor.getString(cursor.getColumnIndex(EjerciciosDbAdapter.C_COLUMNA_DIA1)).equals("7"))
        {
            tv.setText("Curl barra");
        }
        else
        {
            tv.setText("Otros");
        }
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent)
    {
        final LayoutInflater inflater = LayoutInflater.from(context);
        final View view = inflater.inflate(android.R.layout.simple_dropdown_item_1line, parent, false);

        return view;
    }
}

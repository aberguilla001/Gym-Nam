package com.example.asier.gymam;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by asier on 3/03/16.
 */
public class DBTools extends SQLiteOpenHelper {

    private final static int    DB_VERSION = 10;

    public DBTools(Context context) {
        super(context, "myApp.db", null,DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "create table logins (userId Integer primary key autoincrement, "+
                " username text, password text)";
        String query2 = "create table userData (userId Integer primary key autoincrement, "+
                " username text, nombre text, apellidos text, edad text, altura text, peso text, sexo text, objetivo text)";
        sqLiteDatabase.execSQL(query);
        sqLiteDatabase.execSQL(query2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        try{
            System.out.println("UPGRADE DB oldVersion="+oldVersion+" - newVersion="+newVersion);
            //recreateDb(sqLiteDatabase);
            if (oldVersion<10){
                String query = "create table logins (userId Integer primary key autoincrement, "+
                        " username text, password text)";
                sqLiteDatabase.execSQL(query);
                String query2 = "create table userData (userId Integer primary key autoincrement, "+
                        " username text, nombre text, apellidos text, edad text, altura text, peso text, sexo text, objetivo text)";
                sqLiteDatabase.execSQL(query2);
            }
        }
        catch (Exception e){e.printStackTrace();}
    }



    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // super.onDowngrade(db, oldVersion, newVersion);
        System.out.println("DOWNGRADE DB oldVersion="+oldVersion+" - newVersion="+newVersion);
    }

    public User insertUser (User queryValues){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", queryValues.username);
        values.put("password", queryValues.password);
        queryValues.userId=database.insert("logins", null, values);
        database.close();
        return queryValues;
    }

    public User insertarDatos (User queryValues){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username",queryValues.username);
        values.put("nombre", queryValues.nombre);
        values.put("apellidos",queryValues.apellidos);
        values.put("edad",queryValues.edad);
        values.put("altura",queryValues.altura);
        values.put("peso",queryValues.peso);
        values.put("sexo",queryValues.sexo);
        values.put("objetivo",queryValues.objetivo);
        queryValues.userId=database.insert("userData",null,values);
        database.close();
        return queryValues;
    }


    public int updateUserPassword (User queryValues){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", queryValues.username);
        values.put("password", queryValues.password);
        queryValues.userId=database.insert("logins", null, values);
        database.close();
        return database.update("logins", values, "userId = ?", new String[] {String.valueOf(queryValues.userId)});
    }

    public User getUser (String username){
        String query = "Select userId, password from logins where username ='"+username+"'";
        User myUser = new User(0,username,"");
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(query, null);
        if (cursor.moveToFirst()){
            do {
                myUser.userId=cursor.getLong(0);
                myUser.password=cursor.getString(1);
            } while (cursor.moveToNext());
        }
        return myUser;
    }
}
